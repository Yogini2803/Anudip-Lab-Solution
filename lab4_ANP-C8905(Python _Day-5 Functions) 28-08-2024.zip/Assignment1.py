#Q.1)Declare a div() function with two parameters.
# Then call the function and pass two numbers and display their division.

#Declaring  a div() Function here. 
def div(a,b):

# The function calculates the division of 'a' by 'b' and returns the result.
    return a / b

# Now, we call the 'div' function with arguments 11 and 2.
result = div(11,2)
print("Division is : ",result)

"""
OUTPUT : Division is :  5.5
"""
