#Q.2)Declare a square() function with one parameter.
# Then call the function and pass one number and display the square of that number .

#We have define a Square function here.
def square(x):
# The function calculates the square of 'x' (i.e., 'x' multiplied by itself) and returns the result.
    return x * x

result = square(7)
# Here, we call the 'square' function with the argument 7.

print("The Square of 7 :",result)

"""
OUTPUT : The Square of 7 : 49
"""
