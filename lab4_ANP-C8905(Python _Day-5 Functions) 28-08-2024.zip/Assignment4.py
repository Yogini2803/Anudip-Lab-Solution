#Q.4)Accept a name from the user and display that in lower case using lower() function

#We to take input from user
name = input("Enter Your Name :")

# Convert the name to lowercase using the 'lower()' method.
result = name.lower()  
print(f"The name is Lower Case :{result}")

"""
OUTPUT : Enter Your Name :KUNAL
         The name is Lower Case :kunal
"""
